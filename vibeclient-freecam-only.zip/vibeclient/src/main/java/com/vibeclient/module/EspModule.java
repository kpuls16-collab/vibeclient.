package com.vibeclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Highlights chosen blocks through walls. Blocks are picked with #esp_<block_name>. */
public class EspModule extends Module {
    public record Hit(int x, int y, int z, float r, float g, float b) {}

    // Settings
    public int radius = 24;          // scan radius in blocks (cube around you)
    public int scanInterval = 20;    // ticks between scans
    public int maxHits = 3000;       // cap to keep rendering cheap

    public final Set<Block> blocks = ConcurrentHashMap.newKeySet();

    private volatile List<Hit> found = List.of();
    private int ticks;

    public EspModule() {
        super("ESP", "Visuals");
        settings.add(Setting.ofInt("Scan radius", () -> radius, v -> radius = v, 8, 64, 4));
        settings.add(Setting.ofInt("Scan interval", () -> scanInterval, v -> scanInterval = v, 5, 100, 5));
    }

    public List<Hit> getFound() { return found; }

    @Override
    protected void onEnable() { ticks = scanInterval; } // scan immediately

    @Override
    protected void onDisable() { found = List.of(); }

    public void clearBlocks() {
        blocks.clear();
        found = List.of();
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) { found = List.of(); return; }
        if (blocks.isEmpty()) { found = List.of(); return; }
        if (++ticks < scanInterval) return;
        ticks = 0;

        BlockPos c = p.blockPosition();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        List<Hit> out = new ArrayList<>();

        scan:
        for (int x = c.getX() - radius; x <= c.getX() + radius; x++) {
            for (int z = c.getZ() - radius; z <= c.getZ() + radius; z++) {
                for (int y = c.getY() - radius; y <= c.getY() + radius; y++) {
                    m.set(x, y, z);
                    Block b = mc.level.getBlockState(m).getBlock();
                    if (blocks.contains(b)) {
                        out.add(new Hit(x, y, z, red(b), green(b), blue(b)));
                        if (out.size() >= maxHits) break scan;
                    }
                }
            }
        }
        found = List.copyOf(out);
    }

    // Stable, distinct colour per block derived from its registry name.
    private static int rgb(Block b) {
        int h = BuiltInRegistries.BLOCK.getKey(b).getPath().hashCode();
        float hue = (h & 0xFFFF) / 65535f;
        return java.awt.Color.HSBtoRGB(hue, 0.85f, 1f);
    }
    private static float red(Block b)   { return ((rgb(b) >> 16) & 0xFF) / 255f; }
    private static float green(Block b) { return ((rgb(b) >> 8) & 0xFF) / 255f; }
    private static float blue(Block b)  { return (rgb(b) & 0xFF) / 255f; }
}
