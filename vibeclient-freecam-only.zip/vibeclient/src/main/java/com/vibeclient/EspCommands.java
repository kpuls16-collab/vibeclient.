package com.vibeclient;

import com.vibeclient.module.EspModule;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;

import java.util.Locale;
import java.util.StringJoiner;

/**
 * Chat commands (never sent to the server):
 *   #esp_diamond_ore   add / remove a block
 *   #esp_list          show tracked blocks
 *   #esp_clear         remove all
 */
public final class EspCommands {
    private EspCommands() {}

    /** @return true if the message was an ESP command and should NOT be sent. */
    public static boolean handle(String message) {
        String msg = message.trim();
        if (!msg.toLowerCase(Locale.ROOT).startsWith("#esp_")) return false;

        EspModule esp = VibeClient.MODULES.get(EspModule.class);
        String arg = msg.substring(5).trim().toLowerCase(Locale.ROOT).replace(' ', '_');
        if (arg.startsWith("minecraft:")) arg = arg.substring("minecraft:".length());

        switch (arg) {
            case "clear" -> {
                esp.clearBlocks();
                say("ESP cleared.");
            }
            case "list" -> {
                if (esp.blocks.isEmpty()) { say("ESP is tracking nothing. Use #esp_<block>."); }
                else {
                    StringJoiner j = new StringJoiner(", ");
                    for (Block b : esp.blocks) j.add(BuiltInRegistries.BLOCK.getKey(b).getPath());
                    say("ESP tracking: " + j);
                }
            }
            default -> {
                Block block = find(arg);
                if (block == null) {
                    say("Unknown block: " + arg);
                } else if (esp.blocks.remove(block)) {
                    say("ESP removed: " + arg);
                } else {
                    esp.blocks.add(block);
                    if (!esp.isEnabled()) esp.setEnabled(true);
                    say("ESP added: " + arg);
                }
            }
        }
        return true;
    }

    private static Block find(String path) {
        for (Block b : BuiltInRegistries.BLOCK) {
            if (BuiltInRegistries.BLOCK.getKey(b).getPath().equals(path)) return b;
        }
        return null;
    }

    private static void say(String text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.sendSystemMessage(Component.literal("[Vibe] " + text));
    }
}
