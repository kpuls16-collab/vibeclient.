package com.vibeclient.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Hold a respawn anchor in your hotbar and hold right click:
 * place anchor -> switch to glowstone and charge it -> switch to totem and detonate
 * -> switch back to the anchor. Repeats while you keep holding right click.
 * Does nothing in the Nether (anchors don't explode there).
 */
public class AnchorAuraModule extends Module {
    private enum State { IDLE, CHARGE, EXPLODE, RESTORE }

    // Settings
    public int stepDelay = 1;   // ticks between steps
    public int cooldown = 2;    // ticks after a cycle before the next one starts

    private State state = State.IDLE;
    private int timer;
    private int cooldownTimer;
    private int waited;
    private int anchorSlot;
    private BlockPos anchorPos;

    public AnchorAuraModule() {
        super("Anchor Aura", "Combat");
        settings.add(Setting.ofInt("Step delay", () -> stepDelay, v -> stepDelay = v, 0, 10, 1));
        settings.add(Setting.ofInt("Cooldown", () -> cooldown, v -> cooldown = v, 0, 20, 1));
    }

    @Override
    protected void onDisable() { reset(); }

    private void reset() {
        state = State.IDLE;
        timer = 0;
        waited = 0;
        anchorPos = null;
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null) { reset(); return; }
        if (mc.level.dimension().equals(Level.NETHER)) { reset(); return; }

        if (cooldownTimer > 0) cooldownTimer--;
        if (timer > 0) { timer--; return; }

        switch (state) {
            case IDLE -> {
                if (cooldownTimer > 0 || !mc.options.keyUse.isDown()) return;
                if (!p.getMainHandItem().is(Items.RESPAWN_ANCHOR)) return;
                if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;

                anchorSlot = p.getInventory().getSelectedSlot();
                BlockPos clicked = hit.getBlockPos();

                if (mc.level.getBlockState(clicked).is(Blocks.RESPAWN_ANCHOR)) {
                    // Already aiming at an anchor: skip placing and use it.
                    anchorPos = clicked;
                } else {
                    BlockPos target = clicked.relative(hit.getDirection());
                    if (!mc.level.getBlockState(target).isAir()) return;
                    mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, hit);
                    p.swing(InteractionHand.MAIN_HAND);
                    anchorPos = target;
                }
                waited = 0;
                state = State.CHARGE;
                timer = stepDelay;
            }
            case CHARGE -> {
                if (!mc.level.getBlockState(anchorPos).is(Blocks.RESPAWN_ANCHOR)) {
                    // Placement not confirmed by the server yet; wait a few ticks, then give up.
                    if (++waited > 5) reset();
                    return;
                }
                int slot = findHotbar(p, Items.GLOWSTONE);
                if (slot == -1) { selectSlot(p, anchorSlot); reset(); return; }
                selectSlot(p, slot);
                useOnAnchor(mc, p);
                state = State.EXPLODE;
                timer = stepDelay;
            }
            case EXPLODE -> {
                int slot = findHotbar(p, Items.TOTEM_OF_UNDYING);
                if (slot == -1) { selectSlot(p, anchorSlot); reset(); return; }
                selectSlot(p, slot);
                useOnAnchor(mc, p);
                state = State.RESTORE;
                timer = stepDelay;
            }
            case RESTORE -> {
                selectSlot(p, anchorSlot);
                reset();
                cooldownTimer = cooldown;
            }
        }
    }

    private void useOnAnchor(Minecraft mc, LocalPlayer p) {
        BlockHitResult hit = new BlockHitResult(Vec3.atCenterOf(anchorPos), Direction.UP, anchorPos, false);
        mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, hit);
        p.swing(InteractionHand.MAIN_HAND);
    }

    private static int findHotbar(LocalPlayer p, Item item) {
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getItem(i).is(item)) return i;
        }
        return -1;
    }

    /** If this fails to compile, the selected-slot accessor was renamed in 26.1. */
    private static void selectSlot(LocalPlayer p, int slot) {
        p.getInventory().setSelectedSlot(slot);
    }
}
