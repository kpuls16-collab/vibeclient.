package com.vibeclient.module;

import com.vibeclient.EspRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Scans loaded chunks from bedrock to build height and scores them:
 *  - "base %": weighted count of chests, hoppers, diamond/gold blocks, redstone, pistons,
 *              barrels, armor stands, item frames
 *  - "sus": overall player-activity score (the above plus furnaces, torches, lanterns, glass...)
 * Sus chunks get a coloured slab drawn through walls at the height of the activity.
 * Only chunks your client has loaded can be scanned. Villages and other generated
 * structures can look like bases, so treat results as hints.
 */
public class SusChunksModule extends Module {
    public record Info(int cx, int cz, float base, float activity, int y) {}

    // Settings
    public int radiusChunks = 12;      // how far out to scan
    public int chunksPerTick = 2;      // scan budget per tick
    public int rescanTicks = 600;      // re-scan a chunk after this many ticks
    public float susThreshold = 20f;   // activity score needed to flag a chunk as sus
    public float fullBaseScore = 40f;  // base score that counts as 100%
    public int minBasePercent = 15;    // hide base chunks below this

    // Blocks that count toward "base %" (weight each).
    private static final Map<Block, Float> BASE = new HashMap<>();
    // Extra blocks that only count toward general activity.
    private static final Map<Block, Float> ACTIVITY = new HashMap<>();
    static {
        BASE.put(Blocks.CHEST, 2f);
        BASE.put(Blocks.TRAPPED_CHEST, 2f);
        BASE.put(Blocks.BARREL, 2f);
        BASE.put(Blocks.ENDER_CHEST, 3f);
        BASE.put(Blocks.HOPPER, 2f);
        BASE.put(Blocks.DIAMOND_BLOCK, 4f);
        BASE.put(Blocks.GOLD_BLOCK, 3f);
        BASE.put(Blocks.NETHERITE_BLOCK, 6f);
        BASE.put(Blocks.REDSTONE_BLOCK, 1f);
        BASE.put(Blocks.REDSTONE_WIRE, 0.25f);
        BASE.put(Blocks.REPEATER, 1f);
        BASE.put(Blocks.COMPARATOR, 1f);
        BASE.put(Blocks.OBSERVER, 1f);
        BASE.put(Blocks.PISTON, 2f);
        BASE.put(Blocks.STICKY_PISTON, 2f);

        ACTIVITY.put(Blocks.FURNACE, 1f);
        ACTIVITY.put(Blocks.BLAST_FURNACE, 1f);
        ACTIVITY.put(Blocks.SMOKER, 1f);
        ACTIVITY.put(Blocks.CRAFTING_TABLE, 1f);
        ACTIVITY.put(Blocks.ENCHANTING_TABLE, 2f);
        ACTIVITY.put(Blocks.DISPENSER, 1f);
        ACTIVITY.put(Blocks.DROPPER, 1f);
        ACTIVITY.put(Blocks.TORCH, 0.5f);
        ACTIVITY.put(Blocks.WALL_TORCH, 0.5f);
        ACTIVITY.put(Blocks.LANTERN, 1f);
        ACTIVITY.put(Blocks.GLASS, 0.5f);
    }

    private static final float ARMOR_STAND = 3f;
    private static final float ITEM_FRAME = 2f;

    private final Map<Long, Info> infos = new ConcurrentHashMap<>();
    private final Map<Long, Integer> lastScan = new HashMap<>();
    private final ArrayDeque<int[]> queue = new ArrayDeque<>();
    private volatile List<EspRenderer.Box> boxes = List.of();
    private int tickCounter;

    public SusChunksModule() {
        super("Sus Chunks", "Visuals");
        settings.add(Setting.ofInt("Radius (chunks)", () -> radiusChunks, v -> radiusChunks = v, 4, 24, 2));
        settings.add(Setting.ofDouble("Sus threshold", () -> susThreshold, v -> susThreshold = (float) v, 5.0, 80.0, 5.0));
        settings.add(Setting.ofInt("Min base %", () -> minBasePercent, v -> minBasePercent = v, 0, 100, 5));
    }

    public List<EspRenderer.Box> getBoxes() { return boxes; }
    public Map<Long, Info> getInfos() { return infos; }

    public int basePercent(Info i) {
        return Math.min(100, Math.round(i.base() / fullBaseScore * 100f));
    }

    public boolean isSus(Info i) { return i.activity() >= susThreshold; }

    public void clear() {
        infos.clear();
        lastScan.clear();
        queue.clear();
        boxes = List.of();
    }

    @Override
    protected void onDisable() {
        queue.clear();
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        tickCounter++;

        if (queue.isEmpty() && tickCounter % 20 == 0) rebuildQueue(mc, p);
        for (int i = 0; i < chunksPerTick && !queue.isEmpty(); i++) {
            int[] c = queue.poll();
            scanChunk(mc, c[0], c[1]);
        }

        if (tickCounter % 20 == 0) showCurrentChunk(p);
    }

    private static long key(int cx, int cz) {
        return ((long) cx << 32) ^ (cz & 0xffffffffL);
    }

    private void rebuildQueue(Minecraft mc, LocalPlayer p) {
        int pcx = p.blockPosition().getX() >> 4;
        int pcz = p.blockPosition().getZ() >> 4;
        List<int[]> todo = new ArrayList<>();
        for (int dx = -radiusChunks; dx <= radiusChunks; dx++) {
            for (int dz = -radiusChunks; dz <= radiusChunks; dz++) {
                int cx = pcx + dx, cz = pcz + dz;
                Integer last = lastScan.get(key(cx, cz));
                if (last != null && tickCounter - last < rescanTicks) continue;
                if (mc.level.getChunkSource().getChunkNow(cx, cz) == null) continue;
                todo.add(new int[]{cx, cz});
            }
        }
        todo.sort(Comparator.comparingInt(c -> (c[0] - pcx) * (c[0] - pcx) + (c[1] - pcz) * (c[1] - pcz)));
        queue.addAll(todo);
    }

    private void scanChunk(Minecraft mc, int cx, int cz) {
        LevelChunk chunk = mc.level.getChunkSource().getChunkNow(cx, cz);
        if (chunk == null) return;
        lastScan.put(key(cx, cz), tickCounter);

        float base = 0, activity = 0;
        long ySum = 0;
        int yCount = 0;

        LevelChunkSection[] sections = chunk.getSections();
        int minY = chunk.getMinY();
        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection sec = sections[i];
            if (sec == null || sec.hasOnlyAir()) continue;
            // Palette check: skip the 4096-block loop when no interesting block can be in here.
            if (!sec.maybeHas(s -> BASE.containsKey(s.getBlock()) || ACTIVITY.containsKey(s.getBlock()))) continue;

            int y0 = minY + i * 16;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        Block b = sec.getBlockState(x, y, z).getBlock();
                        Float w = BASE.get(b);
                        if (w != null) {
                            base += w; activity += w;
                            ySum += y0 + y; yCount++;
                        } else {
                            Float a = ACTIVITY.get(b);
                            if (a != null) { activity += a; ySum += y0 + y; yCount++; }
                        }
                    }
                }
            }
        }

        // Armor stands and item frames are entities, not blocks.
        AABB column = new AABB(cx * 16, minY, cz * 16, cx * 16 + 16, minY + chunk.getHeight(), cz * 16 + 16);
        for (Entity e : mc.level.getEntities((Entity) null, column)) {
            var t = e.getType();
            float w = 0;
            if (t == EntityType.ARMOR_STAND) w = ARMOR_STAND;
            else if (t == EntityType.ITEM_FRAME || t == EntityType.GLOW_ITEM_FRAME) w = ITEM_FRAME;
            if (w > 0) {
                base += w; activity += w;
                ySum += (long) e.getY(); yCount++;
            }
        }

        if (activity <= 0) {
            infos.remove(key(cx, cz));
        } else {
            int y = yCount > 0 ? (int) (ySum / yCount) : 64;
            infos.put(key(cx, cz), new Info(cx, cz, base, activity, y));
        }
        rebuildBoxes();
    }

    private void rebuildBoxes() {
        List<EspRenderer.Box> out = new ArrayList<>();
        for (Info i : infos.values()) {
            int pct = basePercent(i);
            boolean sus = isSus(i);
            if (!sus && pct < minBasePercent) continue;

            float r, g, b;
            if (pct >= 50)      { r = 1f; g = 0.15f; b = 0.15f; }  // red: very likely a base
            else if (pct >= 25) { r = 1f; g = 0.55f; b = 0.1f; }   // orange
            else                { r = 1f; g = 0.9f;  b = 0.1f; }   // yellow: sus
            float x0 = i.cx() * 16, z0 = i.cz() * 16;
            out.add(new EspRenderer.Box(x0, i.y(), z0, x0 + 16, i.y() + 0.3f, z0 + 16, r, g, b, 0.28f));
        }
        boxes = List.copyOf(out);
    }

    private void showCurrentChunk(LocalPlayer p) {
        Info i = infos.get(key(p.blockPosition().getX() >> 4, p.blockPosition().getZ() >> 4));
        if (i == null) return;
        int pct = basePercent(i);
        if (pct < minBasePercent && !isSus(i)) return;
        p.sendOverlayMessage(Component.literal(
                "Chunk " + i.cx() + ", " + i.cz() + "  |  Base: " + pct + "%  |  "
                        + (isSus(i) ? "SUS" : "ok") + " (" + Math.round(i.activity()) + ")"));
    }
}
