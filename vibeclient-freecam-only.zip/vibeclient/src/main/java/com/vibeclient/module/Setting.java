package com.vibeclient.module;

import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** One adjustable value on a module (shown in the module's config page and saved to disk). */
public final class Setting {
    public enum Kind { INT, DOUBLE, BOOL }

    private final String name;
    private final Kind kind;
    private final DoubleSupplier get;
    private final DoubleConsumer set;
    private final double min, max, step;

    private Setting(String name, Kind kind, DoubleSupplier get, DoubleConsumer set, double min, double max, double step) {
        this.name = name; this.kind = kind; this.get = get; this.set = set;
        this.min = min; this.max = max; this.step = step;
    }

    public static Setting ofInt(String name, IntSupplier g, IntConsumer s, int min, int max, int step) {
        return new Setting(name, Kind.INT, () -> g.getAsInt(), v -> s.accept((int) Math.round(v)), min, max, step);
    }

    public static Setting ofDouble(String name, DoubleSupplier g, DoubleConsumer s, double min, double max, double step) {
        return new Setting(name, Kind.DOUBLE, g, s, min, max, step);
    }

    public static Setting ofBool(String name, BooleanSupplier g, Consumer<Boolean> s) {
        return new Setting(name, Kind.BOOL, () -> g.getAsBoolean() ? 1 : 0, v -> s.accept(v >= 0.5), 0, 1, 1);
    }

    public String name() { return name; }
    public boolean isBool() { return kind == Kind.BOOL; }
    public boolean boolValue() { return get.getAsDouble() >= 0.5; }

    public String display() {
        double v = get.getAsDouble();
        return switch (kind) {
            case BOOL -> v >= 0.5 ? "ON" : "OFF";
            case INT -> String.valueOf((int) Math.round(v));
            case DOUBLE -> String.format(Locale.ROOT, "%.1f", v);
        };
    }

    /** dir = -1 or +1. Booleans just flip. */
    public void adjust(int dir) {
        if (kind == Kind.BOOL) { set.accept(boolValue() ? 0 : 1); return; }
        double v = get.getAsDouble() + dir * step;
        v = Math.max(min, Math.min(max, v));
        set.accept(Math.round(v * 100.0) / 100.0);
    }

    public String serialize() { return Double.toString(get.getAsDouble()); }

    public void deserialize(String s) {
        try {
            double v = Double.parseDouble(s.trim());
            set.accept(Math.max(min, Math.min(max, v)));
        } catch (NumberFormatException ignored) {}
    }
}
